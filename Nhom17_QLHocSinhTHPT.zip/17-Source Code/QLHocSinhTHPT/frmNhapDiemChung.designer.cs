﻿namespace QLHocSinhTHPT
{
    partial class frmNhapDiemChung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNhapDiemChung));
            this.groupBoxDanhSach = new System.Windows.Forms.GroupBox();
            this.ctxMenu = new DevComponents.DotNetBar.ContextMenuBar();
            this.btnMenu = new DevComponents.DotNetBar.ButtonItem();
            this.btnXDiem = new DevComponents.DotNetBar.ButtonItem();
            this.btnLDiem = new DevComponents.DotNetBar.ButtonItem();
            this.btnClose = new DevComponents.DotNetBar.ButtonItem();
            this.dGVDiem = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.colMaHocSinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHoTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDiemMieng = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDiem15Phut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDiem45Phut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDiemThi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingNavigatorDiem = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnLuuDiem = new System.Windows.Forms.ToolStripButton();
            this.btnXemDiem = new System.Windows.Forms.ToolStripButton();
            this.btnThoat = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnHelp = new System.Windows.Forms.ToolStripButton();
            this.navPaneLeft = new DevComponents.DotNetBar.NavigationPane();
            this.navPanelNhapDuLieu = new DevComponents.DotNetBar.NavigationPanePanel();
            this.btnHienThiDanhSach = new DevComponents.DotNetBar.ButtonX();
            this.btnThemMonHoc = new DevComponents.DotNetBar.ButtonX();
            this.btnThemHocKy = new DevComponents.DotNetBar.ButtonX();
            this.btnThemNamHoc = new DevComponents.DotNetBar.ButtonX();
            this.btnThemLop = new DevComponents.DotNetBar.ButtonX();
            this.label01 = new System.Windows.Forms.Label();
            this.label02 = new System.Windows.Forms.Label();
            this.label04 = new System.Windows.Forms.Label();
            this.cmbMonHoc = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbNamHoc = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbHocKy = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbLop = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.label03 = new System.Windows.Forms.Label();
            this.buttonItemNhapDuLieu = new DevComponents.DotNetBar.ButtonItem();
            this.navPanelCapNhatDuLieu = new DevComponents.DotNetBar.NavigationPanePanel();
            this.btnHienThiDanhSachSD = new DevComponents.DotNetBar.ButtonX();
            this.label05 = new System.Windows.Forms.Label();
            this.label06 = new System.Windows.Forms.Label();
            this.label08 = new System.Windows.Forms.Label();
            this.cmbMonHocSD = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbNamHocSD = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbHocKySD = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.cmbLopSD = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.label07 = new System.Windows.Forms.Label();
            this.buttonItemCapNhatDuLieu = new DevComponents.DotNetBar.ButtonItem();
            this.superTooltip = new DevComponents.DotNetBar.SuperTooltip();
            this.groupBoxDanhSach.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctxMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGVDiem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorDiem)).BeginInit();
            this.bindingNavigatorDiem.SuspendLayout();
            this.navPaneLeft.SuspendLayout();
            this.navPanelNhapDuLieu.SuspendLayout();
            this.navPanelCapNhatDuLieu.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxDanhSach
            // 
            this.groupBoxDanhSach.Controls.Add(this.ctxMenu);
            this.groupBoxDanhSach.Controls.Add(this.dGVDiem);
            this.groupBoxDanhSach.Controls.Add(this.bindingNavigatorDiem);
            this.groupBoxDanhSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxDanhSach.Location = new System.Drawing.Point(190, 0);
            this.groupBoxDanhSach.Name = "groupBoxDanhSach";
            this.groupBoxDanhSach.Size = new System.Drawing.Size(644, 368);
            this.groupBoxDanhSach.TabIndex = 3;
            this.groupBoxDanhSach.TabStop = false;
            this.groupBoxDanhSach.Text = "Danh sách nhập điểm";
            // 
            // ctxMenu
            // 
            this.ctxMenu.DockSide = DevComponents.DotNetBar.eDockSide.Document;
            this.ctxMenu.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnMenu});
            this.ctxMenu.Location = new System.Drawing.Point(274, 180);
            this.ctxMenu.Name = "ctxMenu";
            this.ctxMenu.Size = new System.Drawing.Size(75, 25);
            this.ctxMenu.Stretch = true;
            this.ctxMenu.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.ctxMenu.TabIndex = 5;
            this.ctxMenu.TabStop = false;
            this.ctxMenu.Text = "ctxMenu";
            // 
            // btnMenu
            // 
            this.btnMenu.AutoExpandOnClick = true;
            this.btnMenu.ImagePaddingHorizontal = 8;
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Shape = new DevComponents.DotNetBar.RoundRectangleShapeDescriptor(2);
            this.btnMenu.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnXDiem,
            this.btnLDiem,
            this.btnClose});
            this.btnMenu.Text = "Menu";
            // 
            // btnXDiem
            // 
            this.btnXDiem.Image = global::QLHocSinhTHPT.Properties.Resources.xemdiem;
            this.btnXDiem.ImagePaddingHorizontal = 8;
            this.btnXDiem.Name = "btnXDiem";
            this.btnXDiem.Text = "Xem điểm";
            this.btnXDiem.Click += new System.EventHandler(this.btnXemDiem_Click);
            // 
            // btnLDiem
            // 
            this.btnLDiem.Image = global::QLHocSinhTHPT.Properties.Resources.save;
            this.btnLDiem.ImagePaddingHorizontal = 8;
            this.btnLDiem.Name = "btnLDiem";
            this.btnLDiem.Shortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlS);
            this.btnLDiem.Text = "Lưu vào bảng điểm";
            this.btnLDiem.Click += new System.EventHandler(this.btnLuuDiem_Click);
            // 
            // btnClose
            // 
            this.btnClose.Image = global::QLHocSinhTHPT.Properties.Resources.exit;
            this.btnClose.ImagePaddingHorizontal = 8;
            this.btnClose.Name = "btnClose";
            this.btnClose.Shortcuts.Add(DevComponents.DotNetBar.eShortcut.AltF4);
            this.btnClose.Text = "Đóng cửa sổ này";
            this.btnClose.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // dGVDiem
            // 
            this.dGVDiem.AllowUserToAddRows = false;
            this.dGVDiem.AllowUserToDeleteRows = false;
            this.dGVDiem.AllowUserToResizeRows = false;
            this.dGVDiem.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(243)))), ((int)(((byte)(250)))));
            this.dGVDiem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dGVDiem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaHocSinh,
            this.colHoTen,
            this.colDiemMieng,
            this.colDiem15Phut,
            this.colDiem45Phut,
            this.colDiemThi});
            this.ctxMenu.SetContextMenuEx(this.dGVDiem, this.btnMenu);
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dGVDiem.DefaultCellStyle = dataGridViewCellStyle5;
            this.dGVDiem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGVDiem.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.dGVDiem.Location = new System.Drawing.Point(3, 51);
            this.dGVDiem.Name = "dGVDiem";
            this.dGVDiem.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dGVDiem.Size = new System.Drawing.Size(638, 314);
            this.dGVDiem.TabIndex = 5;
            this.dGVDiem.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dGVNhapDiemChung_DataError);
            // 
            // colMaHocSinh
            // 
            this.colMaHocSinh.DataPropertyName = "MaHocSinh";
            this.colMaHocSinh.HeaderText = "Mã học sinh";
            this.colMaHocSinh.MaxInputLength = 6;
            this.colMaHocSinh.Name = "colMaHocSinh";
            this.colMaHocSinh.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colMaHocSinh.Width = 80;
            // 
            // colHoTen
            // 
            this.colHoTen.DataPropertyName = "HoTen";
            this.colHoTen.HeaderText = "Họ và tên";
            this.colHoTen.MaxInputLength = 30;
            this.colHoTen.Name = "colHoTen";
            this.colHoTen.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.colHoTen.Width = 155;
            // 
            // colDiemMieng
            // 
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDiemMieng.DefaultCellStyle = dataGridViewCellStyle1;
            this.colDiemMieng.HeaderText = "Điểm miệng";
            this.colDiemMieng.MaxInputLength = 30;
            this.colDiemMieng.Name = "colDiemMieng";
            this.colDiemMieng.Width = 90;
            // 
            // colDiem15Phut
            // 
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Courier New", 9.75F);
            this.colDiem15Phut.DefaultCellStyle = dataGridViewCellStyle2;
            this.colDiem15Phut.HeaderText = "Điểm 15 phút";
            this.colDiem15Phut.MaxInputLength = 30;
            this.colDiem15Phut.Name = "colDiem15Phut";
            this.colDiem15Phut.Width = 90;
            // 
            // colDiem45Phut
            // 
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Courier New", 9.75F);
            this.colDiem45Phut.DefaultCellStyle = dataGridViewCellStyle3;
            this.colDiem45Phut.HeaderText = "Điểm 45 phút";
            this.colDiem45Phut.MaxInputLength = 30;
            this.colDiem45Phut.Name = "colDiem45Phut";
            this.colDiem45Phut.Width = 90;
            // 
            // colDiemThi
            // 
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colDiemThi.DefaultCellStyle = dataGridViewCellStyle4;
            this.colDiemThi.HeaderText = "Điểm thi";
            this.colDiemThi.MaxInputLength = 8;
            this.colDiemThi.Name = "colDiemThi";
            this.colDiemThi.Width = 90;
            // 
            // bindingNavigatorDiem
            // 
            this.bindingNavigatorDiem.AddNewItem = null;
            this.bindingNavigatorDiem.AutoSize = false;
            this.bindingNavigatorDiem.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigatorDiem.CountItemFormat = "của {0}";
            this.bindingNavigatorDiem.DeleteItem = null;
            this.bindingNavigatorDiem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.btnLuuDiem,
            this.btnXemDiem,
            this.btnThoat,
            this.bindingNavigatorSeparator3,
            this.btnHelp});
            this.bindingNavigatorDiem.Location = new System.Drawing.Point(3, 16);
            this.bindingNavigatorDiem.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigatorDiem.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigatorDiem.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigatorDiem.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigatorDiem.Name = "bindingNavigatorDiem";
            this.bindingNavigatorDiem.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigatorDiem.Size = new System.Drawing.Size(638, 35);
            this.bindingNavigatorDiem.TabIndex = 4;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 32);
            this.bindingNavigatorCountItem.Text = "của {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Tổng số dòng trong danh sách";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 32);
            this.bindingNavigatorMoveFirstItem.Text = "Đến đầu danh sách";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 32);
            this.bindingNavigatorMovePreviousItem.Text = "Trở lại dòng trước";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 35);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 21);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Vị trí hiện tại";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 35);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 32);
            this.bindingNavigatorMoveNextItem.Text = "Tới dòng kế tiếp";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 32);
            this.bindingNavigatorMoveLastItem.Text = "Đến cuối danh sách";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 35);
            // 
            // btnLuuDiem
            // 
            this.btnLuuDiem.Image = global::QLHocSinhTHPT.Properties.Resources.save;
            this.btnLuuDiem.Name = "btnLuuDiem";
            this.btnLuuDiem.RightToLeftAutoMirrorImage = true;
            this.btnLuuDiem.Size = new System.Drawing.Size(70, 32);
            this.btnLuuDiem.Text = "Lưu điểm";
            this.btnLuuDiem.Click += new System.EventHandler(this.btnLuuDiem_Click);
            // 
            // btnXemDiem
            // 
            this.btnXemDiem.Image = global::QLHocSinhTHPT.Properties.Resources.xemdiem;
            this.btnXemDiem.Name = "btnXemDiem";
            this.btnXemDiem.RightToLeftAutoMirrorImage = true;
            this.btnXemDiem.Size = new System.Drawing.Size(72, 32);
            this.btnXemDiem.Text = "Xem điểm";
            this.btnXemDiem.Click += new System.EventHandler(this.btnXemDiem_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Image = global::QLHocSinhTHPT.Properties.Resources.exit;
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.RightToLeftAutoMirrorImage = true;
            this.btnThoat.Size = new System.Drawing.Size(55, 32);
            this.btnThoat.Text = "Thoát";
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // bindingNavigatorSeparator3
            // 
            this.bindingNavigatorSeparator3.Name = "bindingNavigatorSeparator3";
            this.bindingNavigatorSeparator3.Size = new System.Drawing.Size(6, 35);
            // 
            // btnHelp
            // 
            this.btnHelp.AutoToolTip = false;
            this.btnHelp.Image = global::QLHocSinhTHPT.Properties.Resources.help;
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.RightToLeftAutoMirrorImage = true;
            this.btnHelp.Size = new System.Drawing.Size(23, 32);
            this.superTooltip.SetSuperTooltip(this.btnHelp, new DevComponents.DotNetBar.SuperTooltipInfo("Cách nhập điểm cho môn học", "Nhấn F1 để biết thêm về cách nhập điểm", "Nếu loại điểm có nhiều cột điểm thì mỗi điểm nhập cách nhau một dấu chấm phẩy như" +
                        " hình bên.<br />\r\nGiả sử: Có 3 cột điểm miệng là 5.5; 7 và 9 điểm thì nhập: <b>5" +
                        ".5;7;9</b>", global::QLHocSinhTHPT.Properties.Resources.cachnhapdiem, global::QLHocSinhTHPT.Properties.Resources.help, DevComponents.DotNetBar.eTooltipColor.Office2003, true, true, new System.Drawing.Size(400, 125)));
            // 
            // navPaneLeft
            // 
            this.navPaneLeft.CanCollapse = true;
            this.navPaneLeft.Controls.Add(this.navPanelNhapDuLieu);
            this.navPaneLeft.Controls.Add(this.navPanelCapNhatDuLieu);
            this.navPaneLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.navPaneLeft.ItemPaddingBottom = 2;
            this.navPaneLeft.ItemPaddingTop = 2;
            this.navPaneLeft.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItemNhapDuLieu,
            this.buttonItemCapNhatDuLieu});
            this.navPaneLeft.Location = new System.Drawing.Point(0, 0);
            this.navPaneLeft.Name = "navPaneLeft";
            this.navPaneLeft.NavigationBarHeight = 102;
            this.navPaneLeft.Padding = new System.Windows.Forms.Padding(1);
            this.navPaneLeft.Size = new System.Drawing.Size(190, 368);
            this.navPaneLeft.Style = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.navPaneLeft.TabIndex = 0;
            // 
            // 
            // 
            this.navPaneLeft.TitlePanel.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.navPaneLeft.TitlePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.navPaneLeft.TitlePanel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.navPaneLeft.TitlePanel.Location = new System.Drawing.Point(1, 1);
            this.navPaneLeft.TitlePanel.Name = "panelTitle";
            this.navPaneLeft.TitlePanel.Size = new System.Drawing.Size(188, 24);
            this.navPaneLeft.TitlePanel.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.navPaneLeft.TitlePanel.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.navPaneLeft.TitlePanel.Style.Border = DevComponents.DotNetBar.eBorderType.RaisedInner;
            this.navPaneLeft.TitlePanel.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.navPaneLeft.TitlePanel.Style.BorderSide = DevComponents.DotNetBar.eBorderSide.Bottom;
            this.navPaneLeft.TitlePanel.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.navPaneLeft.TitlePanel.Style.GradientAngle = 90;
            this.navPaneLeft.TitlePanel.Style.MarginLeft = 4;
            this.navPaneLeft.TitlePanel.TabIndex = 0;
            this.navPaneLeft.TitlePanel.Text = "Nhập điểm học sinh";
            // 
            // navPanelNhapDuLieu
            // 
            this.navPanelNhapDuLieu.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.navPanelNhapDuLieu.Controls.Add(this.btnHienThiDanhSach);
            this.navPanelNhapDuLieu.Controls.Add(this.btnThemMonHoc);
            this.navPanelNhapDuLieu.Controls.Add(this.btnThemHocKy);
            this.navPanelNhapDuLieu.Controls.Add(this.btnThemNamHoc);
            this.navPanelNhapDuLieu.Controls.Add(this.btnThemLop);
            this.navPanelNhapDuLieu.Controls.Add(this.label01);
            this.navPanelNhapDuLieu.Controls.Add(this.label02);
            this.navPanelNhapDuLieu.Controls.Add(this.label04);
            this.navPanelNhapDuLieu.Controls.Add(this.cmbMonHoc);
            this.navPanelNhapDuLieu.Controls.Add(this.cmbNamHoc);
            this.navPanelNhapDuLieu.Controls.Add(this.cmbHocKy);
            this.navPanelNhapDuLieu.Controls.Add(this.cmbLop);
            this.navPanelNhapDuLieu.Controls.Add(this.label03);
            this.navPanelNhapDuLieu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navPanelNhapDuLieu.Location = new System.Drawing.Point(1, 25);
            this.navPanelNhapDuLieu.Name = "navPanelNhapDuLieu";
            this.navPanelNhapDuLieu.ParentItem = this.buttonItemNhapDuLieu;
            this.navPanelNhapDuLieu.Size = new System.Drawing.Size(188, 240);
            this.navPanelNhapDuLieu.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.navPanelNhapDuLieu.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.navPanelNhapDuLieu.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2;
            this.navPanelNhapDuLieu.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.navPanelNhapDuLieu.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.navPanelNhapDuLieu.Style.GradientAngle = 90;
            this.navPanelNhapDuLieu.TabIndex = 1;
            // 
            // btnHienThiDanhSach
            // 
            this.btnHienThiDanhSach.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnHienThiDanhSach.ColorTable = DevComponents.DotNetBar.eButtonColor.Office2007WithBackground;
            this.btnHienThiDanhSach.Location = new System.Drawing.Point(11, 190);
            this.btnHienThiDanhSach.Name = "btnHienThiDanhSach";
            this.btnHienThiDanhSach.Size = new System.Drawing.Size(164, 23);
            this.btnHienThiDanhSach.TabIndex = 9;
            this.btnHienThiDanhSach.Text = "Hiển thị danh sách";
            this.btnHienThiDanhSach.Click += new System.EventHandler(this.btnHienThiDanhSach_Click);
            // 
            // btnThemMonHoc
            // 
            this.btnThemMonHoc.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnThemMonHoc.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnThemMonHoc.Image = global::QLHocSinhTHPT.Properties.Resources.add;
            this.btnThemMonHoc.Location = new System.Drawing.Point(155, 160);
            this.btnThemMonHoc.Name = "btnThemMonHoc";
            this.btnThemMonHoc.Size = new System.Drawing.Size(20, 20);
            this.btnThemMonHoc.TabIndex = 8;
            this.btnThemMonHoc.Click += new System.EventHandler(this.btnThemMonHoc_Click);
            // 
            // btnThemHocKy
            // 
            this.btnThemHocKy.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnThemHocKy.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnThemHocKy.Image = global::QLHocSinhTHPT.Properties.Resources.add;
            this.btnThemHocKy.Location = new System.Drawing.Point(155, 115);
            this.btnThemHocKy.Name = "btnThemHocKy";
            this.btnThemHocKy.Size = new System.Drawing.Size(20, 20);
            this.btnThemHocKy.TabIndex = 6;
            this.btnThemHocKy.Click += new System.EventHandler(this.btnThemHocKy_Click);
            // 
            // btnThemNamHoc
            // 
            this.btnThemNamHoc.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnThemNamHoc.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnThemNamHoc.Image = global::QLHocSinhTHPT.Properties.Resources.add;
            this.btnThemNamHoc.Location = new System.Drawing.Point(155, 25);
            this.btnThemNamHoc.Name = "btnThemNamHoc";
            this.btnThemNamHoc.Size = new System.Drawing.Size(20, 20);
            this.btnThemNamHoc.TabIndex = 2;
            this.btnThemNamHoc.Click += new System.EventHandler(this.btnThemNamHoc_Click);
            // 
            // btnThemLop
            // 
            this.btnThemLop.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnThemLop.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnThemLop.Image = global::QLHocSinhTHPT.Properties.Resources.add;
            this.btnThemLop.Location = new System.Drawing.Point(155, 70);
            this.btnThemLop.Name = "btnThemLop";
            this.btnThemLop.Size = new System.Drawing.Size(20, 20);
            this.btnThemLop.TabIndex = 4;
            this.btnThemLop.Click += new System.EventHandler(this.btnThemLop_Click);
            // 
            // label01
            // 
            this.label01.AutoSize = true;
            this.label01.Location = new System.Drawing.Point(8, 10);
            this.label01.Name = "label01";
            this.label01.Size = new System.Drawing.Size(53, 13);
            this.label01.TabIndex = 0;
            this.label01.Text = "Năm học:";
            // 
            // label02
            // 
            this.label02.AutoSize = true;
            this.label02.Location = new System.Drawing.Point(8, 55);
            this.label02.Name = "label02";
            this.label02.Size = new System.Drawing.Size(28, 13);
            this.label02.TabIndex = 0;
            this.label02.Text = "Lớp:";
            // 
            // label04
            // 
            this.label04.AutoSize = true;
            this.label04.Location = new System.Drawing.Point(8, 145);
            this.label04.Name = "label04";
            this.label04.Size = new System.Drawing.Size(52, 13);
            this.label04.TabIndex = 0;
            this.label04.Text = "Môn học:";
            // 
            // cmbMonHoc
            // 
            this.cmbMonHoc.DisplayMember = "Text";
            this.cmbMonHoc.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbMonHoc.FormattingEnabled = true;
            this.cmbMonHoc.ItemHeight = 14;
            this.cmbMonHoc.Location = new System.Drawing.Point(11, 160);
            this.cmbMonHoc.Name = "cmbMonHoc";
            this.cmbMonHoc.Size = new System.Drawing.Size(138, 20);
            this.cmbMonHoc.TabIndex = 7;
            // 
            // cmbNamHoc
            // 
            this.cmbNamHoc.DisplayMember = "Text";
            this.cmbNamHoc.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbNamHoc.FormattingEnabled = true;
            this.cmbNamHoc.ItemHeight = 14;
            this.cmbNamHoc.Location = new System.Drawing.Point(11, 25);
            this.cmbNamHoc.Name = "cmbNamHoc";
            this.cmbNamHoc.Size = new System.Drawing.Size(138, 20);
            this.cmbNamHoc.TabIndex = 1;
            this.cmbNamHoc.SelectedIndexChanged += new System.EventHandler(this.cmbNamHoc_SelectedIndexChanged);
            // 
            // cmbHocKy
            // 
            this.cmbHocKy.DisplayMember = "Text";
            this.cmbHocKy.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbHocKy.FormattingEnabled = true;
            this.cmbHocKy.ItemHeight = 14;
            this.cmbHocKy.Location = new System.Drawing.Point(11, 115);
            this.cmbHocKy.Name = "cmbHocKy";
            this.cmbHocKy.Size = new System.Drawing.Size(138, 20);
            this.cmbHocKy.TabIndex = 5;
            // 
            // cmbLop
            // 
            this.cmbLop.DisplayMember = "Text";
            this.cmbLop.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbLop.FormattingEnabled = true;
            this.cmbLop.ItemHeight = 14;
            this.cmbLop.Location = new System.Drawing.Point(11, 70);
            this.cmbLop.Name = "cmbLop";
            this.cmbLop.Size = new System.Drawing.Size(138, 20);
            this.cmbLop.TabIndex = 3;
            this.cmbLop.SelectedIndexChanged += new System.EventHandler(this.cmbLop_SelectedIndexChanged);
            // 
            // label03
            // 
            this.label03.AutoSize = true;
            this.label03.Location = new System.Drawing.Point(8, 100);
            this.label03.Name = "label03";
            this.label03.Size = new System.Drawing.Size(44, 13);
            this.label03.TabIndex = 0;
            this.label03.Text = "Học kỳ:";
            // 
            // buttonItemNhapDuLieu
            // 
            this.buttonItemNhapDuLieu.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemNhapDuLieu.Checked = true;
            this.buttonItemNhapDuLieu.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemNhapDuLieu.Image")));
            this.buttonItemNhapDuLieu.ImagePaddingHorizontal = 8;
            this.buttonItemNhapDuLieu.Name = "buttonItemNhapDuLieu";
            this.buttonItemNhapDuLieu.OptionGroup = "navBar";
            this.buttonItemNhapDuLieu.Text = "Nhập điểm học sinh";
            // 
            // navPanelCapNhatDuLieu
            // 
            this.navPanelCapNhatDuLieu.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.navPanelCapNhatDuLieu.Controls.Add(this.btnHienThiDanhSachSD);
            this.navPanelCapNhatDuLieu.Controls.Add(this.label05);
            this.navPanelCapNhatDuLieu.Controls.Add(this.label06);
            this.navPanelCapNhatDuLieu.Controls.Add(this.label08);
            this.navPanelCapNhatDuLieu.Controls.Add(this.cmbMonHocSD);
            this.navPanelCapNhatDuLieu.Controls.Add(this.cmbNamHocSD);
            this.navPanelCapNhatDuLieu.Controls.Add(this.cmbHocKySD);
            this.navPanelCapNhatDuLieu.Controls.Add(this.cmbLopSD);
            this.navPanelCapNhatDuLieu.Controls.Add(this.label07);
            this.navPanelCapNhatDuLieu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.navPanelCapNhatDuLieu.Location = new System.Drawing.Point(1, 1);
            this.navPanelCapNhatDuLieu.Name = "navPanelCapNhatDuLieu";
            this.navPanelCapNhatDuLieu.ParentItem = this.buttonItemCapNhatDuLieu;
            this.navPanelCapNhatDuLieu.Size = new System.Drawing.Size(188, 366);
            this.navPanelCapNhatDuLieu.Style.Alignment = System.Drawing.StringAlignment.Center;
            this.navPanelCapNhatDuLieu.Style.BackColor1.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground;
            this.navPanelCapNhatDuLieu.Style.BackColor2.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.BarBackground2;
            this.navPanelCapNhatDuLieu.Style.BorderColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.navPanelCapNhatDuLieu.Style.ForeColor.ColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.ItemText;
            this.navPanelCapNhatDuLieu.Style.GradientAngle = 90;
            this.navPanelCapNhatDuLieu.TabIndex = 2;
            // 
            // btnHienThiDanhSachSD
            // 
            this.btnHienThiDanhSachSD.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.btnHienThiDanhSachSD.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.btnHienThiDanhSachSD.Location = new System.Drawing.Point(11, 190);
            this.btnHienThiDanhSachSD.Name = "btnHienThiDanhSachSD";
            this.btnHienThiDanhSachSD.Size = new System.Drawing.Size(164, 23);
            this.btnHienThiDanhSachSD.TabIndex = 5;
            this.btnHienThiDanhSachSD.Text = "Hiển thị danh sách";
            this.btnHienThiDanhSachSD.Click += new System.EventHandler(this.btnHienThiDanhSachSD_Click);
            // 
            // label05
            // 
            this.label05.AutoSize = true;
            this.label05.Location = new System.Drawing.Point(8, 10);
            this.label05.Name = "label05";
            this.label05.Size = new System.Drawing.Size(53, 13);
            this.label05.TabIndex = 0;
            this.label05.Text = "Năm học:";
            // 
            // label06
            // 
            this.label06.AutoSize = true;
            this.label06.Location = new System.Drawing.Point(8, 55);
            this.label06.Name = "label06";
            this.label06.Size = new System.Drawing.Size(28, 13);
            this.label06.TabIndex = 0;
            this.label06.Text = "Lớp:";
            // 
            // label08
            // 
            this.label08.AutoSize = true;
            this.label08.Location = new System.Drawing.Point(8, 145);
            this.label08.Name = "label08";
            this.label08.Size = new System.Drawing.Size(52, 13);
            this.label08.TabIndex = 0;
            this.label08.Text = "Môn học:";
            // 
            // cmbMonHocSD
            // 
            this.cmbMonHocSD.DisplayMember = "Text";
            this.cmbMonHocSD.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbMonHocSD.FormattingEnabled = true;
            this.cmbMonHocSD.ItemHeight = 14;
            this.cmbMonHocSD.Location = new System.Drawing.Point(11, 160);
            this.cmbMonHocSD.Name = "cmbMonHocSD";
            this.cmbMonHocSD.Size = new System.Drawing.Size(164, 20);
            this.cmbMonHocSD.TabIndex = 4;
            // 
            // cmbNamHocSD
            // 
            this.cmbNamHocSD.DisplayMember = "Text";
            this.cmbNamHocSD.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbNamHocSD.FormattingEnabled = true;
            this.cmbNamHocSD.ItemHeight = 14;
            this.cmbNamHocSD.Location = new System.Drawing.Point(11, 25);
            this.cmbNamHocSD.Name = "cmbNamHocSD";
            this.cmbNamHocSD.Size = new System.Drawing.Size(164, 20);
            this.cmbNamHocSD.TabIndex = 1;
            this.cmbNamHocSD.SelectedIndexChanged += new System.EventHandler(this.cmbNamHocSD_SelectedIndexChanged);
            // 
            // cmbHocKySD
            // 
            this.cmbHocKySD.DisplayMember = "Text";
            this.cmbHocKySD.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbHocKySD.FormattingEnabled = true;
            this.cmbHocKySD.ItemHeight = 14;
            this.cmbHocKySD.Location = new System.Drawing.Point(11, 115);
            this.cmbHocKySD.Name = "cmbHocKySD";
            this.cmbHocKySD.Size = new System.Drawing.Size(164, 20);
            this.cmbHocKySD.TabIndex = 3;
            // 
            // cmbLopSD
            // 
            this.cmbLopSD.DisplayMember = "Text";
            this.cmbLopSD.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmbLopSD.FormattingEnabled = true;
            this.cmbLopSD.ItemHeight = 14;
            this.cmbLopSD.Location = new System.Drawing.Point(11, 70);
            this.cmbLopSD.Name = "cmbLopSD";
            this.cmbLopSD.Size = new System.Drawing.Size(164, 20);
            this.cmbLopSD.TabIndex = 2;
            this.cmbLopSD.SelectedIndexChanged += new System.EventHandler(this.cmbLopSD_SelectedIndexChanged);
            // 
            // label07
            // 
            this.label07.AutoSize = true;
            this.label07.Location = new System.Drawing.Point(8, 100);
            this.label07.Name = "label07";
            this.label07.Size = new System.Drawing.Size(44, 13);
            this.label07.TabIndex = 0;
            this.label07.Text = "Học kỳ:";
            // 
            // buttonItemCapNhatDuLieu
            // 
            this.buttonItemCapNhatDuLieu.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItemCapNhatDuLieu.Image = ((System.Drawing.Image)(resources.GetObject("buttonItemCapNhatDuLieu.Image")));
            this.buttonItemCapNhatDuLieu.ImagePaddingHorizontal = 8;
            this.buttonItemCapNhatDuLieu.Name = "buttonItemCapNhatDuLieu";
            this.buttonItemCapNhatDuLieu.OptionGroup = "navBar";
            this.buttonItemCapNhatDuLieu.Text = "Cập nhật điểm học sinh";
            // 
            // superTooltip
            // 
            this.superTooltip.DefaultFont = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // frmNhapDiemChung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 368);
            this.Controls.Add(this.groupBoxDanhSach);
            this.Controls.Add(this.navPaneLeft);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmNhapDiemChung";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NHẬP ĐIỂM HỌC SINH";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmNhapDiemChung_Load);
            this.groupBoxDanhSach.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ctxMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGVDiem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigatorDiem)).EndInit();
            this.bindingNavigatorDiem.ResumeLayout(false);
            this.bindingNavigatorDiem.PerformLayout();
            this.navPaneLeft.ResumeLayout(false);
            this.navPanelNhapDuLieu.ResumeLayout(false);
            this.navPanelNhapDuLieu.PerformLayout();
            this.navPanelCapNhatDuLieu.ResumeLayout(false);
            this.navPanelCapNhatDuLieu.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        #region Components
        private System.Windows.Forms.GroupBox groupBoxDanhSach;
        private DevComponents.DotNetBar.NavigationPane navPaneLeft;
        private DevComponents.DotNetBar.NavigationPanePanel navPanelNhapDuLieu;
        private DevComponents.DotNetBar.ButtonItem buttonItemNhapDuLieu;
        private DevComponents.DotNetBar.NavigationPanePanel navPanelCapNhatDuLieu;
        private DevComponents.DotNetBar.ButtonItem buttonItemCapNhatDuLieu;
        private DevComponents.DotNetBar.ButtonX btnHienThiDanhSach;
        private DevComponents.DotNetBar.ButtonX btnThemMonHoc;
        private DevComponents.DotNetBar.ButtonX btnThemHocKy;
        private DevComponents.DotNetBar.ButtonX btnThemNamHoc;
        private DevComponents.DotNetBar.ButtonX btnThemLop;
        private DevComponents.DotNetBar.ContextMenuBar ctxMenu;
        private DevComponents.DotNetBar.ButtonItem btnMenu;
        private DevComponents.DotNetBar.ButtonItem btnLDiem;
        private DevComponents.DotNetBar.ButtonItem btnXDiem;
        private DevComponents.DotNetBar.ButtonItem btnClose;
        private DevComponents.DotNetBar.SuperTooltip superTooltip;
        private System.Windows.Forms.ToolStripButton btnHelp;
        private DevComponents.DotNetBar.Controls.DataGridViewX dGVDiem;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbMonHoc;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbHocKy;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbLop;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbNamHoc;
        private System.Windows.Forms.Label label01;
        private System.Windows.Forms.Label label02;
        private System.Windows.Forms.Label label03;
        private System.Windows.Forms.Label label04;
        private System.Windows.Forms.Label label05;
        private System.Windows.Forms.Label label06;
        private System.Windows.Forms.Label label07;
        private System.Windows.Forms.Label label08;
        private DevComponents.DotNetBar.ButtonX btnHienThiDanhSachSD;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbMonHocSD;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbNamHocSD;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbHocKySD;
        private DevComponents.DotNetBar.Controls.ComboBoxEx cmbLopSD;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaHocSinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHoTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDiemMieng;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDiem15Phut;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDiem45Phut;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDiemThi;
        private System.Windows.Forms.BindingNavigator bindingNavigatorDiem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton btnLuuDiem;
        private System.Windows.Forms.ToolStripButton btnThoat;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator3;
        private System.Windows.Forms.ToolStripButton btnXemDiem;
        #endregion
    }
}